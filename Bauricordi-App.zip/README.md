# Bauricordi
Progetto Expo/React Native per Android, iPhone e Web.

## Avvio
1. `npm install`
2. `npx expo start`

Questa base riproduce la home del prototipo Bauricordi e include navigazione iniziale per Ricordi, Promemoria, Chiedi a Bauri e Profilo, oltre al primo spazio Premium.
